import re
import spacy
from pdfminer.high_level import extract_text

nlp = spacy.load("en_core_web_sm")

def extract_text_from_pdf(pdf_path):
    try:
        return extract_text(pdf_path)
    except Exception as e:
        return ""

def extract_info(text):
    doc = nlp(text)

    # Name (first PERSON entity)
    name = next((ent.text for ent in doc.ents if ent.label_ == "PERSON"), "N/A")

    # Email
    email = re.search(r'\S+@\S+', text)
    email = email.group() if email else "N/A"

    # Phone
    phone = re.search(r'(\+?\d[\d\s-]{8,}\d)', text)
    phone = phone.group() if phone else "N/A"

    return {
        "name": name.strip(),
        "email": email.strip(),
        "phone": phone.strip()
    }
